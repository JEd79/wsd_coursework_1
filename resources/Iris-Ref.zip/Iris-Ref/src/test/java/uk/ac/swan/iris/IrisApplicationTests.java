package uk.ac.swan.iris;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IrisApplicationTests {

    @Test
    void contextLoads() {
    }

}
