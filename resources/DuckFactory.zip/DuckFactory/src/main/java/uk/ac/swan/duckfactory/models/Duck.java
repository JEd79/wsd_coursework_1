package uk.ac.swan.duckfactory.models;

public class Duck {
    private String colour;
    private String species;
    private int age;
    private String name;
    private Integer id;

    public Duck(String colour, String species, int age, String name, Integer id) {
        this.colour = colour;
        this.species = species;
        this.age = age;
        this.name = name;
        this.id = id;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
