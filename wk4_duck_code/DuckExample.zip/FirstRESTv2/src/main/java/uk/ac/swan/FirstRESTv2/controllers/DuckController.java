package uk.ac.swan.FirstRESTv2.controllers;

import uk.ac.swan.FirstRESTv2.models.Duck;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/ducks")
public class DuckController {

    private static int duckIdCounter = 0;
    private static List<Duck> theDucks = new ArrayList<>();
    // @GetMapping
    // public String getSomeDuck() {
    //     return "Hello from the ducks.";
    // }

    // @GetMapping
    // public int getSomeDuck() {
    //     return 123;
    // }

    // @GetMapping()
    // public Duck getDuckObject() {
    //     return new Duck("Wilfred", 12);
    // }

    @GetMapping()
    public List<Duck> getSomeDucks() {
        return theDucks;
    }

    @PostMapping()
    public ResponseEntity<Duck> createDuck(@RequestBody Duck someDuck) { 
        
        //validation
        if(someDuck.getName() == null) {
            //throw new IllegalArgumentException("No name specified");
            return ResponseEntity.badRequest().body(someDuck);
        }
        
        int duckId = duckIdCounter;
        someDuck.setId(duckId);
        duckIdCounter++;
        theDucks.add(someDuck);
        return ResponseEntity.ok(someDuck);
    }

    @DeleteMapping("{id}")
    public void deleteDuck(@PathVariable int id) {
        theDucks.removeIf((Duck a) -> a.getId() == id);
    }
    
    @GetMapping("/count")
    public int getNumOfDucks() {
        return theDucks.size();
    }
    
}