package uk.ac.swan.duckfactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DuckFactoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(DuckFactoryApplication.class, args);
    }

}
