//from week 5

package uk.ac.swan.FirstRESTv2.services;

import tools.jackson.databind.ObjectMapper;
import uk.ac.swan.FirstRESTv2.models.Duck;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DuckLoaderService {
    public static List<Duck> loadDucksFromResources() {
        ObjectMapper mapper = new ObjectMapper();
        Duck[] ducks = mapper.readValue(DuckLoaderService.class.getClassLoader().getResourceAsStream("data/ducks_100.json"),Duck[].class);
        return new ArrayList<>(Arrays.asList(ducks));
    }
}
