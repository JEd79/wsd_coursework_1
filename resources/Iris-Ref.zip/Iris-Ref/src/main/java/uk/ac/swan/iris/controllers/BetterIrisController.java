package uk.ac.swan.iris.controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import uk.ac.swan.iris.models.Iris;
import uk.ac.swan.iris.services.IrisReaderService;

@RestController
@RequestMapping("better/irises")
public class BetterIrisController {

    private List<Iris> data;
    private final String token = "123456";

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        data = IrisReaderService.readIris();
    }

    @GetMapping("all")
    public ResponseEntity<List<Iris>> getIris(@RequestParam(required = false, name = "species") String species) {
        List<Iris> result = new ArrayList<>();


        if (species != null) {
            for (Iris iris : data) {
                if (species.equalsIgnoreCase(iris.getSpecies())) {
                    result.add(iris);
                }
            }
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.noContent().build();
        }

    }

    @GetMapping("{idx}")
    public ResponseEntity<Iris> getIris(@PathVariable int idx) {
        if (idx < 0 || idx >= data.size()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(data.get(idx));
    }

    @GetMapping("sample")
    public ResponseEntity<List<Iris>> getIrisSample(@RequestParam int start,
                                                    @RequestParam int end) {
        try {
            List<Iris> sample = data.subList(start, end);
            return ResponseEntity.ok(sample);

        } catch (IndexOutOfBoundsException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Collections.emptyList());
        }
    }

    @GetMapping("count")
    public ResponseEntity<Integer> getCount() {
        return ResponseEntity.ok(data.size());
    }

    @DeleteMapping("{idx}")
    public ResponseEntity<String> deleteIris(@PathVariable int idx,
                                             @RequestHeader("User-Agent") String userAgent,
                                             @RequestHeader("Authorization") String authorization) {

        System.out.println("Request received from user agent: " + userAgent);
        System.out.println("Authorization: " + authorization);

        if (!authorization.equals(token)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Delete unsuccessful: invalid token!");
        }

        if (idx < 0 || idx >= data.size()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Delete unsuccessful: index out of bounds!");
        }

        data.remove(idx);
        return ResponseEntity.ok("Delete successful!");
    }

    @PutMapping("{idx}")
    public ResponseEntity<Iris> updateIris(@RequestBody Iris iris,
                                           @PathVariable int idx) {
        if (idx < 0 || idx >= data.size()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        data.set(idx, iris);
        return ResponseEntity.ok(iris);
    }

    @PostMapping
    public ResponseEntity<Iris> createIris(@RequestBody Iris iris) {
        data.add(iris);
        return ResponseEntity.status(HttpStatus.CREATED).body(iris);
    }
}
