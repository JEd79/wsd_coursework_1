package uk.ac.swan.iris.models;


public class Iris {
    private int id;
    private double sepalLength;
    private double sepalWidth;
    private double petalLength;
    private double petalWidth;
    private String species;

    public Iris() {}

    public Iris(double sepalLength, double sepalWidth, double petalLength, double petalWidth, String species) {
        this.sepalLength = sepalLength;
        this.sepalWidth = sepalWidth;
        this.petalLength = petalLength;
        this.petalWidth = petalWidth;
        this.species = species;
    }


    public void setSepalLength(double sepalLength) {
        this.sepalLength = sepalLength;
    }

    public void setPetalWidth(double petalWidth) {
        this.petalWidth = petalWidth;
    }

    public void setSepalWidth(double sepalWidth) {
        this.sepalWidth = sepalWidth;
    }

    public void setPetalLength(double petalLength) {
        this.petalLength = petalLength;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public double getSepalLength() {
        return sepalLength;
    }

    public double getSepalWidth() {
        return sepalWidth;
    }



    public String getSpecies() {
        return species;
    }

    public double getPetalWidth() {
        return petalWidth;
    }

}