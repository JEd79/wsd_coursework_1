package uk.ac.swan.FirstREST;

public class Character {
    private Integer id;
    private String name;
    private Integer level;
    private String classType;

    public Character(Integer id, String name, Integer level, String classType) {
        this.id = id;
        this.name = name;
        this.level = level;
        this.classType = classType;
    }

    public String getClassType() {
        return classType;
    }

    public void setClassType(String classType) {
        this.classType = classType;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }


}
