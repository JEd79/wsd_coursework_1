package uk.ac.swan.FirstRESTv2.controllers;

import uk.ac.swan.FirstRESTv2.models.Duck;
import uk.ac.swan.FirstRESTv2.services.DuckLoaderService;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


@RestController
@RequestMapping("/ducks")
public class DuckController {

    private static final String DELETE_TOKEN = "duckdelete!";
    private static int duckIdCounter = 0;
    private static List<Duck> theDucks = new ArrayList<>();
    // @GetMapping
    // public String getSomeDuck() {
    //     return "Hello from the ducks.";
    // }

    // @GetMapping
    // public int getSomeDuck() {
    //     return 123;
    // }

    // @GetMapping()
    // public Duck getDuckObject() {
    //     return new Duck("Wilfred", 12);
    // }

    // // Original code from week 4
    // @GetMapping()
    // public List<Duck> getSomeDucks() {
    //     return theDucks;
    // }

    //Updated code from week 5
    @GetMapping()
    public ResponseEntity<List<Duck>> getSomeDucks(@RequestParam(defaultValue = "") String colour, @RequestParam (value="min_age", defaultValue = "0") int minAge, @RequestParam (value="max_age") int maxAge) {
        //System.out.println(colour); //Used to check that RequestParam worked e.g. returned a colour in terminal
        
        if(minAge < 0 || minAge > maxAge) {
            //return ResponseEntity.badRequest().build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();//alternative approach to above line
        }
        
        
        List<Duck> theResult = new ArrayList<>();
        for (Duck d : theDucks) {
            if (colour.isEmpty() || d.getColour().equalsIgnoreCase(colour)) {
                if(d.getAge() >= minAge && d.getAge() <= maxAge) {
                    theResult.add(d);
                }
            }
        }
        return ResponseEntity.ok(theResult);
    }

    @GetMapping("/count")
    public int getNumOfDucks() {
        return theDucks.size();
    }

    // // Original code from week 4
    // @PostMapping()
    // public ResponseEntity<Duck> createDuck(@RequestBody Duck someDuck) { 
        
    //     //validation
    //     if(someDuck.getName() == null) {
    //         //throw new IllegalArgumentException("No name specified");
    //         return ResponseEntity.badRequest().body(someDuck);
    //     }
        
    //     int duckId = duckIdCounter;
    //     someDuck.setId(duckId);
    //     duckIdCounter++;
    //     theDucks.add(someDuck);
    //     return ResponseEntity.ok(someDuck);
    // }

    // Code from week 5
    //Read below as the method createDuck is going to get called when a Post request comes in
    //That post request is gong to have a body which contains a Duck object
    //Status codes found at: developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status
    @PostMapping()
    public Duck createDuck(@RequestBody Duck someDuck) { 
        int duckId = duckIdCounter;
        someDuck.setId(duckId);
        duckIdCounter++;
        theDucks.add(someDuck);
        return someDuck;
    }

    // Original code from week 4
    // @DeleteMapping("{id}")
    // public void deleteDuck(@PathVariable int id) {
    //     theDucks.removeIf((Duck a) -> a.getId() == id);
    // }

    //added in week 5
    //@DeleteMapping("{id}")
    //public void deleteDuck(@PathVariable int id) { //this was changed to below in session 2
    // Note: As far as Java is concerned when it sees the deleteDuck method is called,
    // it identifies it as a boolean with 2 parameters - an int and a String). 
    // The funky annotations are called dependency injection. 
    // The @stuff is for SpringBoot
    // public boolean deleteDuck(@PathVariable int id, @RequestHeader (value = "Authorization", defaultValue = "") String token){
    //     if (token.equalsIgnoreCase(DELETE_TOKEN)) {
    //         int index = -1;
    //         for (int j = 0; j < theDucks.size(); j++) {
    //             if(theDucks.get(j).getId() == id) {
    //                 index = j;
    //                 break;
    //             }
    //         }
    //         theDucks.remove(index);
    //         return true;
    //     } else {
    //         return false;
    //     }
    // }

    //added in week 5. Option not to return a body.
    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    //public void deleteDuck(@PathVariable int id) { //this was changed to below in session 2
    // Note: As far as Java is concerned when it sees the deleteDuck method is called,
    // it identifies it as a boolean with 2 parameters - an int and a String). 
    // The funky annotations are called dependency injection. 
    // The @stuff is for SpringBoot
    public void deleteDuck(@PathVariable int id, @RequestHeader (value = "Authorization", defaultValue = "") String token){
        if (token.equalsIgnoreCase(DELETE_TOKEN)) {
            int index = -1;
            for (int j = 0; j < theDucks.size(); j++) {
                if(theDucks.get(j).getId() == id) {
                    index = j;
                    break;
                }
            }
            theDucks.remove(index);
        }
    }
    
    //From week 5
    @EventListener(ApplicationReadyEvent.class)
    public void initialise() {
        theDucks = DuckLoaderService.loadDucksFromResources();
        for(Duck d : theDucks) {
            int duckId = duckIdCounter++;
            d.setId(duckId);
        }
    }

    
}