package uk.ac.swan.FirstRESTv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstResTv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
