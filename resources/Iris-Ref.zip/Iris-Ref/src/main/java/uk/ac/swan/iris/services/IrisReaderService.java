package uk.ac.swan.iris.services;

import org.springframework.stereotype.Service;
import uk.ac.swan.iris.models.Iris;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class IrisReaderService {

    private static final String FILEPATH = "/home/skaff/ownCloud/Degree Apprenticeship Teaching/CSF205 - 2025 Sept/Teaching Content/Week 5/Examples/Iris/src/main/resources/data/iris.csv";

    public static List<Iris> readIris() {
        List<Iris> data = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(FILEPATH));
            String line;
            int id = 0;

            // Skip the first line of the csv (column names)
            br.readLine();

            // Continue to read data until we hit the last line
            while ((line = br.readLine()) != null) {

                // Split the contents of each line in the csv by commas
                String[] features = line.split(",");
                assert features.length == 5 : String.format("Expected 5 iris features, got %s", features.length);

                // Populate the map of Iris data with new instances constructed from the csv data
                data.add(new Iris(
                        Double.parseDouble(features[0]),
                        Double.parseDouble(features[1]),
                        Double.parseDouble(features[2]),
                        Double.parseDouble(features[3]),
                        features[4].trim())
                );
                id++;
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }
}