package uk.ac.swan.duckfactory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuckFactoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
