package uk.ac.swan.adult;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import uk.ac.swan.adult.services.AdultReaderService;

@SpringBootApplication
public class AdultApplication {
    public static void main(String[] args) {
        SpringApplication.run(AdultApplication.class, args);
    }
}
