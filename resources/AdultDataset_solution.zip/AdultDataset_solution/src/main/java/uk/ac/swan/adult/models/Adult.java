package uk.ac.swan.adult.models;

public class Adult {
    private int age;
    private String workclass;
    private String fnlwgt;
    private String education;
    private double educationNum;
    private String maritalStatus;
    private String occupation;
    private String relationship;
    private String race;
    private String sex;
    private double capitalGain;
    private double capitalLoss;
    private double hoursPerWeek;
    private String nativeCountry;
    private String salaryClass;


    // TASK 5.2: Allows Spring Boot to turn the POST request's JSON into an Adult.
    // This is an empty constructor; the fields are filled using the setters below.
    public Adult() {
    }

    public Adult(int age, String workclass, String fnlwgt, String education, double educationNum, String maritalStatus, String occupation, String relationship, String race, String sex, double capitalGain, double capitalLoss, double hoursPerWeek, String nativeCountry, String salaryClass) {
        this.age = age;
        this.workclass = workclass;
        this.fnlwgt = fnlwgt;
        this.education = education;
        this.educationNum = educationNum;
        this.maritalStatus = maritalStatus;
        this.occupation = occupation;
        this.relationship = relationship;
        this.race = race;
        this.sex = sex;
        this.capitalGain = capitalGain;
        this.capitalLoss = capitalLoss;
        this.hoursPerWeek = hoursPerWeek;
        this.nativeCountry = nativeCountry;
        this.salaryClass = salaryClass;

    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getWorkclass() {
        return workclass;
    }

    public void setWorkclass(String workclass) {
        this.workclass = workclass;
    }

    public String getFnlwgt() {
        return fnlwgt;
    }

    public void setFnlwgt(String fnlwgt) {
        this.fnlwgt = fnlwgt;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public double getEducationNum() {
        return educationNum;
    }

    public void setEducationNum(double educationNum) {
        this.educationNum = educationNum;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public double getCapitalGain() {
        return capitalGain;
    }

    public void setCapitalGain(double capitalGain) {
        this.capitalGain = capitalGain;
    }

    public double getCapitalLoss() {
        return capitalLoss;
    }

    public void setCapitalLoss(double capitalLoss) {
        this.capitalLoss = capitalLoss;
    }

    public double getHoursPerWeek() {
        return hoursPerWeek;
    }

    public void setHoursPerWeek(double hoursPerWeek) {
        this.hoursPerWeek = hoursPerWeek;
    }

    public String getNativeCountry() {
        return nativeCountry;
    }

    public void setNativeCountry(String nativeCountry) {
        this.nativeCountry = nativeCountry;
    }

    public String getSalaryClass() {
        return salaryClass;
    }

    public void setSalaryClass(String salaryClass) {
        this.salaryClass = salaryClass;
    }
}
