package uk.ac.swan.FirstRESTv2.models;

public class Duck {
    
	private Integer id;
    private String name;
    private int age;

    public Duck (String name, int age ) {
        this.name = name;
        this.age = age;
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}


}
