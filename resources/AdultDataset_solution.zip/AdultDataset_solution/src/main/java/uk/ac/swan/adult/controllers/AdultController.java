package uk.ac.swan.adult.controllers;

import uk.ac.swan.adult.models.Adult;
import uk.ac.swan.adult.services.AdultReaderService;

import java.io.IOException;
import java.util.HashMap;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/adults")
public class AdultController {

    // TASK 5.3: Simple token, like DELETE_TOKEN in the lecture's DuckController.
    private static final String DELETE_TOKEN = "adultdelete!";

    // TASK 5.1: Store the Adult records in a HashMap (ID -> Adult).
    private HashMap<Integer, Adult> theAdults = new HashMap<>();

    // TASK 5.2: The next unused ID for a new Adult record.
    private int adultIdCounter = 0;

    // TASK 5.1: Load the CSV into memory when Spring Boot finishes starting.
    // This uses the same @EventListener idea as the lecture's DuckController.
    @EventListener(ApplicationReadyEvent.class)
    public void initialise() {
        try {
            theAdults = AdultReaderService.readAdults();
            adultIdCounter = AdultReaderService.getDataID();
        } catch (IOException e) {
            throw new RuntimeException("Could not read adult.csv", e);
        }
    }

    // TASK 5.1: GET /adults returns the whole dataset.
    // TASK 5.1: GET /adults?salaryClass=%3E50K filters by salary class.
    // TASK 5.4: ResponseEntity.ok(...) sends HTTP 200 with the JSON result.
    @GetMapping
    public ResponseEntity<HashMap<Integer, Adult>> getAdults(
            @RequestParam(defaultValue = "") String salaryClass) {

        HashMap<Integer, Adult> theResult = new HashMap<>();

        // Similar to looping through the Ducks, but using HashMap keys.
        for (Integer id : theAdults.keySet()) {
            Adult adult = theAdults.get(id);

            // No filter supplied: include everyone. Otherwise: matching class only.
            if (salaryClass.isEmpty() ||
                    adult.getSalaryClass().equalsIgnoreCase(salaryClass)) {
                theResult.put(id, adult);
            }
        }

        return ResponseEntity.ok(theResult);
    }

    // TASK 5.2: POST /adults creates an Adult from JSON in the request body.
    // TASK 5.4: HTTP 201 means a record was created; the body contains that Adult.
    @PostMapping
    public ResponseEntity<Adult> createAdult(@RequestBody Adult newAdult) {
        theAdults.put(adultIdCounter, newAdult);
        adultIdCounter++;

        return ResponseEntity.status(HttpStatus.CREATED).body(newAdult);
    }

    // TASK 5.3: DELETE /adults?min_age=20&max_age=30 removes matching ages.
    // TASK 5.3: A matching Authorization header is required.
    // TASK 5.4: Return an HTTP status that explains the outcome.
    @DeleteMapping
    public ResponseEntity<String> deleteAdults(
            @RequestParam(value = "min_age") int minAge,
            @RequestParam(value = "max_age") int maxAge,
            @RequestHeader(value = "Authorization", defaultValue = "") String token) {

        // TASK 5.3: Do not delete anything if the token is wrong or absent.
        if (!token.equals(DELETE_TOKEN)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Incorrect or missing Authorization token");
        }

        // TASK 5.4: Age ranges such as 30 to 20 do not make sense.
        if (minAge < 0 || maxAge < minAge) {
            return ResponseEntity.badRequest().body("Invalid age range");
        }

        int before = theAdults.size();
        System.err.println(before);

        // TASK 5.3: removeIf is also used in the lecture's DuckController.
        // values() contains the Adult objects stored in the HashMap.
        theAdults.values().removeIf(adult ->
                adult.getAge() >= minAge && adult.getAge() <= maxAge);

        int removed = before - theAdults.size();
        System.err.println(removed);

        // TASK 5.4: Distinguish between no matching records and a successful delete.
        if (removed == 0) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No adults found in that age range");
        }

        return ResponseEntity.ok("Deleted " + removed + " adult records");
    }
}
