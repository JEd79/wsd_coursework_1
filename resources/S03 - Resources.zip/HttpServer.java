import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/*
Class that handles incoming requests from a port and creates a new thread
to handle each of them - overcommented to explain what is going on
 */
public class HttpServer {

    public static void main(String argv[]) {
        try {
            //Create a server socket to wait for incoming calls
            ServerSocket sSoc = new ServerSocket(8080);

            /*
            Repeatedly wait for incoming requests, create a socket and a thread to handle them
            and go back to listening for new requests
            */
            while (true) {
                Socket inSoc = sSoc.accept();
                HandleGet doGet = new HandleGet(inSoc);
                doGet.start();
            }
        } catch (IOException e) {
            System.out.println("Server done died! " + e.getMessage());
        }
    }
}
