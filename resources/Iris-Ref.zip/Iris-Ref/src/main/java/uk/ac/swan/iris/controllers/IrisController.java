package uk.ac.swan.iris.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import uk.ac.swan.iris.models.Iris;
import uk.ac.swan.iris.services.IrisReaderService;

@RestController
@RequestMapping("irises")
public class IrisController {

    private List<Iris> data;
    private final String token = "123456";

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        data = IrisReaderService.readIris();
    }

    @GetMapping("all")
    public List<Iris> getIris(@RequestParam(required = false, name = "species") String species) {
        List<Iris> result = new ArrayList<>();

        if (species != null) {
            for (Iris iris : data) {
                if (species.equalsIgnoreCase(iris.getSpecies())) {
                    result.add(iris);
                }
            }
            return result;
        } else {
            return data;
        }
    }

    @GetMapping("{idx}")
    public Iris getIris(@PathVariable int idx) {
        return data.get(idx);
    }

    @GetMapping("sample")
    public List<Iris> getIrisSample(@RequestParam int start,
                                    @RequestParam int end) {

        List<Iris> sample = new ArrayList<>();

        try {
            sample = data.subList(start, end);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sample;
    }

    @GetMapping("count")
    public int getCount() {
        return data.size();
    }

    @DeleteMapping("{idx}")
    public String deleteIris(@PathVariable int idx,
                           @RequestHeader("User-Agent") String userAgent,
                           @RequestHeader("Authorization") String authorization) {

        String message = "Delete unsuccessful!";

        System.out.println("Request received from user agent: " + userAgent);
        System.out.println("Authorization: " + authorization);

        if (authorization.equals(token)) {
            try {
                data.remove(idx);
                message = "Delete successful!";
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return message;
    }

    @PutMapping("{idx}")
    public Iris updateIris(@RequestBody Iris iris,
                           @PathVariable int idx) {
        data.set(idx, iris);
        return iris;
    }

    @PostMapping
    public Iris createIris(@RequestBody Iris iris) {
        data.add(iris);
        return iris;
    }


}
