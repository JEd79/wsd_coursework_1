package uk.ac.swan.FirstREST;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

//@RestController
@RequestMapping("/characters")
public class CharacterControllerOld {

    // Store characters in a list
    private List<Character> characters = new ArrayList<>();

    //Character counter
    private static int characterIdCounter = 0;

    // GET: Get all characters
    @GetMapping
    public List<Character> getAllCharacters() {
        return characters;
    }

    // GET: Get one character by ID
    @GetMapping("/{id}")
    public Character getCharacter(@PathVariable int id) {
        for (Character character : characters) {
            if (character.getId() == id) {
                return character;
            }
        }
        return null;
    }

    // POST: Add a new character
    @PostMapping
    public String addCharacter(@RequestBody Character character) {
        if (getCharacter(character.getId()) != null) {
            return "Character ID already exists";
        }

        characters.add(character);
        return "Character added";
    }

    // PUT: Update an existing character
    @PutMapping("/{id}")
    public String updateCharacter(@PathVariable Integer id,
                                  @RequestBody Character updated) {

        Character oldCharacter = getCharacter(id);

        if (oldCharacter != null) {
            characters.remove(oldCharacter);
            updated.setId(id);
            characters.add(updated);

            return "Character updated";
        }

        return "Character not found";
    }

    // DELETE: Remove a character
    @DeleteMapping("/{id}")
    public String deleteCharacter(@PathVariable int id) {

        Character character = getCharacter(id);

        if (character != null) {
            characters.remove(character);
            return "Character deleted";
        }

        return "Character not found";
    }
}
