package uk.ac.swan.duckfactory.controllers;

import org.springframework.web.bind.annotation.*;
import uk.ac.swan.duckfactory.models.Duck;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("ducks")
public class DuckController {

    List<Duck> ducks = new ArrayList<>();

    @GetMapping
    public String welcome() {
        return "Welcome to the duckground!";
    }

    @PostMapping
    public Duck createDuck(@RequestBody Duck newduck) {
        ducks.add(newduck);
        return newduck;
    }

    @GetMapping("duck/{id}")
    public String getAll(@PathVariable int id) {
        return "Duck with id " + id + " specified!";
    }
}
