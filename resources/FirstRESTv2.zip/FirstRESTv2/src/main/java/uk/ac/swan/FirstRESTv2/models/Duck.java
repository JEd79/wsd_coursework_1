package uk.ac.swan.FirstRESTv2.models;

public class Duck {
    
	private Integer id;
    private String name;
    private int age;
	private boolean canFly; //added in week 5
	private String colour; //added in week 5
	private int quackVolume; //added in week 5

    public Duck (String name, int age ) {
        this.name = name;
        this.age = age;
    }

	public boolean isCanFly() {
		return canFly;
	}

	public void setCanFly(boolean canFly) {
		this.canFly = canFly;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public int getQuackVolume() {
		return quackVolume;
	}

	public void setQuackVolume(int quackVolume) {
		this.quackVolume = quackVolume;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}


}
