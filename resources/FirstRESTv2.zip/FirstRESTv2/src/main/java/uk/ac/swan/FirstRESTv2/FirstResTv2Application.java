package uk.ac.swan.FirstRESTv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstResTv2Application {

	public static void main(String[] args) {
		SpringApplication.run(FirstResTv2Application.class, args);
	}

}
