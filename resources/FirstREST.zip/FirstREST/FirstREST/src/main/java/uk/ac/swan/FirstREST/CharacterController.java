package uk.ac.swan.FirstREST;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/characters")
public class CharacterController {

    private static int characterIdCounter = 0;
    private static List<Character> characters = new ArrayList<>();

    // GET: Get all characters
    @GetMapping
    public List<Character> getAllCharacters() {
        return characters;
    }

    // GET: Get one character by ID
    @GetMapping("/{id}")
    public Character getCharacter(@PathVariable int id) {
        for (Character character : characters) {
            if (character.getId() == id) {
                return character;
            }
        }
        return null;
    }

    // POST: Add a new character
    @PostMapping
    public ResponseEntity<Character> createCharacter(@RequestBody Character character) {

        // Validation
        if (character.getName() == null) {
            return ResponseEntity.badRequest().body(character);
        }
        int characterId = characterIdCounter;
        character.setId(characterId);
        characterIdCounter++;
        characters.add(character);
        return ResponseEntity.ok(character);
    }

    // PUT: Update an existing character
    @PutMapping("/{id}")
    public void updateCharacter(@PathVariable int id, @RequestBody Character updated) {
        if (getCharacter(id) != null) {
            characters.removeIf((Character a) -> a.getId() == id);
            updated.setId(id);
            characters.add(updated);
        }
    }

    // DELETE: Remove a character
    @DeleteMapping("/{id}")
    public void deleteCharacter(@PathVariable int id) {
        characters.removeIf((Character character) -> character.getId() == id);
    }
}
