import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

class HandleGet extends Thread {
    Socket threadSoc;

    // Constructor saves a reference to the socket we are communicating on
    HandleGet(Socket inSoc) {
        threadSoc = inSoc;
    }

    // Handle the actual incoming request
    public void run() {
        try {
            // Connect input/output stream reader/writer to the socket
            PrintWriter outputHttp =
                    new PrintWriter(threadSoc.getOutputStream());
            BufferedReader in = new BufferedReader(new
                    InputStreamReader(threadSoc.getInputStream()));

            // This is what we are going to send
            String testOutput = "<h1>It Works!</h1>\r\n";
            // It's important there is a *header* that says how many chars there are in our output
            int testLength = testOutput.length();

            /*
            Read and throw away all input until we get to a blank line - HTTP requests are terminated
            by a blank line (technically, two *line feed* characters)
            */

            String inString = "";
            do {
                inString = in.readLine();
                System.out.println(inString);
            } while (!inString.isEmpty());

            /* Write out our header followed by our content - the first three lines are:
            1. The response that says this is HTTP 1.1 and that the output is OK
            2. That the *type* of content is html (which is a subtype of text) - Content-Type is a *header*
            3. Another header saying how many characters are in our output
            4. A blank line - this denotes the end of the header
            5. Our content - followed by another blank line denoting the end of the response
             */
            outputHttp.write("HTTP/1.1 200 OK\r\n");
            outputHttp.write("Content-Type: text/html\r\n");
            outputHttp.write("Content-Length: " + testLength + "\r\n");
            outputHttp.write("\r\n");
            outputHttp.write(testOutput);
            outputHttp.write("\r\n");
            outputHttp.close();
        } catch (IOException e) {
            System.out.println("Whoops! " + e.toString());
        }

        try {
            threadSoc.close();
        } catch (IOException e) {
            System.out.println("Oh no! " + e.toString());
        }
    }
}